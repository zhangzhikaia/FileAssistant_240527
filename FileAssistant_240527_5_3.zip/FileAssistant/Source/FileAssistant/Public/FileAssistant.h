// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

class FFileAssistantModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
private:
	void RegisterToolBarFAMenu();
	
	void OpenFileAssistantPanel();

	void RegisterIconPanelTab();
	
public:
	bool ExecuteAddNewFile();
	
	bool ExecuteAddNewFolder();
	
};
