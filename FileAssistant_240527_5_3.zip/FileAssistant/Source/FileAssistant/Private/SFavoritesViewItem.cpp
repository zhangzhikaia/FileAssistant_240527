﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "SFavoritesViewItem.h"

#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "FFAItem.h"
#include "IconStyle.h"
#include "Widgets/Layout/SScaleBox.h"

void SFavoritesViewItem::Construct(const FArguments& InArgs)
{
	FileItem = InArgs._FileItem;
	/*on rename callback*/
	OnRenameBegin = InArgs._OnRenameBegin;
	OnRenameCommit = InArgs._OnRenameCommit;

	/*size of item name text*/
	FSlateFontInfo SlateFontInfo = FCoreStyle::Get().GetFontStyle(FName("EmbossedText"));
	SlateFontInfo.Size = 8;

	/*image of item icon*/
	const FName BrushName = FIconStyle::Get().GetBrush(FileItem->GetIconName())->GetResourceName();
	const FName DefaultBrushName = FIconStyle::Get().GetDefaultBrush()->GetResourceName();
	
	const FSlateBrush* Brush = BrushName.IsEqual(DefaultBrushName,ENameCase::CaseSensitive) ?
		FToolBarIconStyle::Get().GetBrush(FName("IconSet.folder")):
		FIconStyle::Get().GetBrush(FileItem->GetIconName());

	/*editable textblock*/
	SAssignNew(InlineRenameWidget,SInlineEditableTextBlock)
						.Text(FText::FromString(FileItem->GetBaseName()))
						.Font(SlateFontInfo)
						.OnBeginTextEdit(this, &SFavoritesViewItem::HandleBeginNameChange)
						/*3...when  EnterEditingMode , call OnBeginTextEdit - callback HandleBeginNameChange*/
						.OnTextCommitted(this, &SFavoritesViewItem::HandleNameCommitted);
	
	if(FileItem.IsValid())
	{
		FileItem->OnRenameRequested().BindSP(InlineRenameWidget.Get(), &SInlineEditableTextBlock::EnterEditingMode);
		FileItem->OnRenameCanceled().BindSP(InlineRenameWidget.Get(), &SInlineEditableTextBlock::ExitEditingMode);
		/* 1...bind on rename call EnterEditingMode 
		 */
	}
	
	ChildSlot
	[
		SNew(SVerticalBox)
		+SVerticalBox::Slot()  /*file icon*/
		[
			SNew(SScaleBox)
			.Stretch(EStretch::ScaleToFit)   /*Keep square*/
			[
				SNew(SImage)
				.Image(Brush)  /*file icon*/
			]
		]
		+SVerticalBox::Slot()  /*file name*/
		.AutoHeight()        
		.HAlign(HAlign_Center)
		.VAlign(VAlign_Center)
		[
			InlineRenameWidget.ToSharedRef()
		]
	];
}

void SFavoritesViewItem::HandleBeginNameChange(const FText& OriginalText)
{
	/*4...call OnRenameBegin,it is from Construct input*/
	OnRenameBegin.ExecuteIfBound(FileItem, OriginalText.ToString());
}

void SFavoritesViewItem::HandleNameCommitted(const FText& NewText, ETextCommit::Type CommitInfo)
{
	OnRenameCommit.ExecuteIfBound(FileItem, NewText.ToString(), CommitInfo);
}