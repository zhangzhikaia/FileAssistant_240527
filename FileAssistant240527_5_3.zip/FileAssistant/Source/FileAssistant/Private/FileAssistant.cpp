// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "FileAssistant.h"
#include "FAUtilities.h"
#include "DesktopPlatformModule.h"
#include "EditorDirectories.h"
#include "IconStyle.h"
#include "SFavoritesPanel.h"
#include "ToolMenus.h"
#include "HAL/FileManager.h"
#include "Misc/Paths.h"

#define LOCTEXT_NAMESPACE "FFileAssistantModule"

void FFileAssistantModule::StartupModule()
{
	FIconStyle::InitializeIcons();
	FToolBarIconStyle::Initialize();
	FToolBarIconStyle::ReloadTextures();

	//FileAssistantCommands::Register();
	
	//RegisterToolBarFAMenu();
	UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FFileAssistantModule::RegisterToolBarFAMenu));
	RegisterIconPanelTab();
}

void FFileAssistantModule::ShutdownModule()
{
	UToolMenus::UnRegisterStartupCallback(this);
	UToolMenus::UnregisterOwner(this);

	//FileAssistantCommands::Unregister();
	
	FIconStyle::ShutDownIcons();
	FToolBarIconStyle::ShutDown();
	
	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(FName(FAUtilities::GetFileAssistantName()));
}

void FFileAssistantModule::RegisterToolBarFAMenu()
{
	FToolMenuOwnerScoped OwnerScoped(this);
	
	UToolMenu* ToolbarMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar.PlayToolBar");
	
	FToolMenuSection& Section = ToolbarMenu->FindOrAddSection(FName(FAUtilities::GetFileAssistantName()));
	
	Section.AddEntry(FToolMenuEntry::InitToolBarButton(
		FName(FAUtilities::GetFileAssistantName()),
		FExecuteAction::CreateRaw( this, &FFileAssistantModule::OpenFileAssistantPanel),
		FText::FromString(FAUtilities::GetFileAssistantName()),
		FText::FromString("Open FileAssistant panel"),
		FSlateIcon(FToolBarIconStyle::GetToolBarStyleSetName(),"IconSet.ToolBarIcon")
		)
	);
}

void FFileAssistantModule::OpenFileAssistantPanel()
{
	FGlobalTabmanager::Get()->TryInvokeTab(FName(FAUtilities::GetFileAssistantName()));
}

void FFileAssistantModule::RegisterIconPanelTab()
{
	FGlobalTabmanager::Get()->RegisterTabSpawner(
		FName(FAUtilities::GetFileAssistantName()),
		FOnSpawnTab::CreateLambda([](const FSpawnTabArgs& SpawnTabArgs)
		{
			TSharedRef<SDockTab> TabPtr = SNew(SDockTab)
			.TabRole(ETabRole::NomadTab)
				[
					SNew(SFavoritesPanel)
				];
			TabPtr->SetTabIcon(FToolBarIconStyle::Get().GetBrush(FName("IconSet.ToolBarIcon")));
			return TabPtr;
		}));
}


bool FFileAssistantModule::ExecuteAddNewFile()
{
	IDesktopPlatform* const DesktopPlatform = FDesktopPlatformModule::Get();
	bool bProcess = false;
	if (DesktopPlatform)
	{
		const FString DefaultPath = FEditorDirectories::Get().GetLastDirectory(ELastDirectory::GENERIC_OPEN);
		TArray<FString> OutFiles;
		
		bool bOpened = DesktopPlatform->OpenFileDialog(
			FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr),
			LOCTEXT("FilePickerTitle", "Choose files...").ToString(),
			DefaultPath,
			TEXT(""),
			TEXT("All Files (*.*)|*.*|Image Files (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp|Document Files (*.doc;*.docx;*.pdf;*.txt)|*.doc;*.docx;*.pdf;*.txt"),
			EFileDialogFlags::None,  //Too many choices at a time may cause stuck when triggered again, so only one can be chosen for now.
			OutFiles
			);
		if(bOpened)
		{
			for(FString CurrentFile : OutFiles)
			{
				const FString CurrentFileAbsolutePath = IFileManager::Get().ConvertToAbsolutePathForExternalAppForRead(*CurrentFile);
				/*As long as any one of them succeeds, it is set to true. */
				if(FAUtilities::CreateShortcut(*CurrentFileAbsolutePath)){bProcess = true;}
				
				if(FPaths::GetExtension(CurrentFile).Equals(TEXT("jpg")) || FPaths::GetExtension(CurrentFile).Equals(TEXT("png")))
				{
					if(FAUtilities::CopyTexture(*CurrentFile)){bProcess = true;}
				}
				else
				{
					if(FAUtilities::SaveIconToPng(*CurrentFileAbsolutePath)){bProcess = true;}
				}
			}
			if(bProcess){FIconStyle::RefreshSet();}
		}
	}
	return bProcess;
}

bool FFileAssistantModule::ExecuteAddNewFolder()
{
	IDesktopPlatform* const DesktopPlatform = FDesktopPlatformModule::Get();
	
	if (DesktopPlatform)
	{
		const FString DefaultPath = FEditorDirectories::Get().GetLastDirectory(ELastDirectory::GENERIC_OPEN);
		FString FolderPath;
		bool bOpened = DesktopPlatform->OpenDirectoryDialog(
		FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr),
		LOCTEXT("FolderPickerTitle", "Choose a folder...").ToString(),
		DefaultPath,
		FolderPath
		);
		if(bOpened)
		{
			FString FolderAbsolutePath = IFileManager::Get().ConvertToAbsolutePathForExternalAppForRead(*FolderPath);
			FolderAbsolutePath.ReplaceInline(TEXT("/"), TEXT("\\"));
		
			return FAUtilities::CreateShortcut(*FolderAbsolutePath);  
		}
	}
	return false;
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FFileAssistantModule, FileAssistant)