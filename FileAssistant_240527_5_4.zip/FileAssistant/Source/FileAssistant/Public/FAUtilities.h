// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once
//#include <windows.h>
typedef HICON__* HICON;
typedef _GUID CLSID;

#if 0
namespace Debug
{
	static void Print(const FString& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message);
		}
	}
	static void Print(const int32& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, FString::FromInt(message));
		}
	}
	static void Print(const FText& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message.ToString());
		}
	}
	static void FastPrint()
	{
		Print(TEXT("FastPring : Debug"));
	}
}
#endif

namespace FAUtilities
{
	FString GetFileAssistantName();

	FString GetFileAssistantFolderPath();
	
	FString GetDefaultIconPath();

	FString GetToolBarIconPath();
	
	FString GetIconsDirectory();

	FString GetShortcutsDirectory();

	bool CreateShortcut(const TCHAR* InFilePath);

	FString GetShortcutTargetPath(const TCHAR* InFilePath);
	
	HICON ExtractHIcon(const TCHAR* InFilePath);

	bool GetEncoderClsid(const TCHAR* format, CLSID* pClsid);

	bool SaveIconToPng(const TCHAR* InFilePath);

	bool CopyTexture(const TCHAR* InFilePath);

	bool OpenFileOrFolder(const TCHAR* InPath);

	bool DeleteIconAndShortcut(const TCHAR* InShortcutPath);

	bool RenameIconAndShortcut(const FString OldName,const FString NewName);

}