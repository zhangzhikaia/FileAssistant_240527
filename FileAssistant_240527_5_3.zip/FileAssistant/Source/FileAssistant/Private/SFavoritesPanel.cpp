﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "SFavoritesPanel.h"

#include "Framework/Commands/GenericCommands.h"
#include "FAUtilities.h"
#include "IconStyle.h"
#include "FileAssistant.h"
#include "SFavoritesViewItem.h"
#include "FFAItem.h"

void SFavoritesPanel::Construct(const FArguments& InArgs)
{
	FIconStyle::RefreshSet();
	
	BindCommands();
	
	ChildSlot
	[
		SNew(SVerticalBox)
		+SVerticalBox::Slot() [ConstructTileView()]
		+SVerticalBox::Slot().AutoHeight()
		[
			SNew(SHorizontalBox)
			+SHorizontalBox::Slot()[SNew(SSpacer)] 
			+SHorizontalBox::Slot().AutoWidth().Padding(FMargin(2))
			[
				SNew(SButton)
				.OnClicked_Raw(this,&SFavoritesPanel::HandleAddNewFileButton)
				.ToolTipText(FText::FromString("Select a new file and add it to the panel."))
				[SNew(STextBlock).Text(FText::FromString("New file"))]
			]
			+SHorizontalBox::Slot().AutoWidth().Padding(FMargin(2))
			[
				SNew(SButton)
				.OnClicked_Raw(this,&SFavoritesPanel::HandleAddNewFolderButton)
				.ToolTipText(FText::FromString("Select a new folder and add it to the panel."))
				[SNew(STextBlock).Text(FText::FromString("New folder"))]
			]
		]
	];
}

FReply SFavoritesPanel::OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	if(FileAssistantCommands.IsValid())
	{
		if(FileAssistantCommands->ProcessCommandBindings( InKeyEvent ))
		{
			return FReply::Handled();
		}
	}
	return FReply::Unhandled();
}

TSharedRef<STileView<TSharedPtr<FFAItem>>> SFavoritesPanel::ConstructTileView()
{
	RefreshFFAItems();
	
	ConstructedTileView = SNew(STileView<TSharedPtr<FFAItem>>)
	.ItemHeight(64).ItemWidth(64)
	.ListItemsSource(&FFAItems)  //Generate items based on the number of elements in the array, and pass the elements to the items.
	.OnGenerateTile(this,&SFavoritesPanel::OnGenerateTileItem)  //Construct and return the item widget.
#if WITH_EDITOR
	.OnContextMenuOpening(this,&SFavoritesPanel::HandleFileAssistantContextMenuOpening) //Construct and return the ContextMenu.
#endif
	.OnMouseButtonDoubleClick_Lambda([](TSharedPtr<FFAItem> Item)
	{
		FAUtilities::OpenFileOrFolder(*Item->GetShortcutPath());
	});
	
	return ConstructedTileView.ToSharedRef();
}

TSharedRef<ITableRow> SFavoritesPanel::OnGenerateTileItem(TSharedPtr<FFAItem> InFAItem,
	const TSharedRef<STableViewBase>& OwnerTable)
{
	/*SNew(STileView<TSharedPtr<FFAItem>>).OnGenerateTile()*/
	TSharedPtr< STableRow<TSharedPtr<FFAItem>> > TableRowWidget;
	
	SAssignNew( TableRowWidget, STableRow<TSharedPtr<FFAItem>>, OwnerTable )
		.Padding(FMargin(5.f))
		.ToolTipText(FText::FromString(InFAItem->GetBaseName()));

	TSharedRef<SFavoritesViewItem> Item = SNew(SFavoritesViewItem)
		.FileItem(InFAItem)
		.OnRenameBegin(this,&SFavoritesPanel::AssetRenameBegin)
		/*5...AssetRenameBegin to SFavoritesViewItem - OnRenameBegin*/
		.OnRenameCommit(this,&SFavoritesPanel::AssetRenameCommit);
	
	TableRowWidget->SetContent(Item);
	
	return TableRowWidget.ToSharedRef();
}

#if WITH_EDITOR
TSharedPtr<SWidget> SFavoritesPanel::HandleFileAssistantContextMenuOpening()
{
	/*SNew(STileView<TSharedPtr<FFAItem>>).OnContextMenuOpening()*/
	FMenuBuilder MenuBuilder(true, FileAssistantCommands);
	
	MenuBuilder.BeginSection("FileAssistantOptions", FText::FromString("FileAssistant Options"));
	{
		if(ConstructedTileView.IsValid())
		{
			if (ConstructedTileView->GetNumItemsSelected() == 0) /*没选, 可以添加新文件*/
			{
				MenuBuilder.AddMenuEntry(
					FText::FromString("Add new file"),
					FText::FromString("Select a new file and add it to the panel."),
					FSlateIcon(),
					FExecuteAction::CreateLambda([this](){HandleAddNewFileButton();}));
				
				MenuBuilder.AddMenuEntry(
					FText::FromString("Add new folder"),
					FText::FromString("Select a new folder and add it to the panel."),
					FSlateIcon(),
					FExecuteAction::CreateLambda([this](){HandleAddNewFolderButton();}));
			}
			if (ConstructedTileView->GetNumItemsSelected() > 0) /*只要选了, 无论是1个还是多个, 添加删除*/
			{
				MenuBuilder.AddMenuEntry(FGenericCommands::Get().Delete);
			}
			if (ConstructedTileView->GetNumItemsSelected() == 1)  /*只选一个, 只可以重命名, 打开所在目录等*/
			{
				TSharedPtr<FFAItem> SelectedItem= ConstructedTileView->GetSelectedItems()[0];
				MenuBuilder.AddMenuEntry(
					FText::FromString("Open the directory"),
					FText::FromString("Open the directory"),
					FSlateIcon(),
					FExecuteAction::CreateLambda([](TSharedPtr<FFAItem> InItem){
						FAUtilities::OpenFileOrFolder(*InItem->GetDirectoryPath());
					},SelectedItem));
				
				MenuBuilder.AddMenuEntry(FGenericCommands::Get().Rename);
			}
		}
	}
	MenuBuilder.EndSection();
	
	return SNew(SBorder)
	.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
	.Content()
	[
		MenuBuilder.MakeWidget()
	];
}
#endif

void SFavoritesPanel::RefreshFFAItems()
{
	FFAItems.Reset();
	
	IPlatformFile& platformFile = FPlatformFileManager::Get().GetPlatformFile();
	TArray<FString> FoundFiles;
	platformFile.FindFiles(FoundFiles,*FAUtilities::GetShortcutsDirectory(),*FString(TEXT("lnk")));
	
	for(const FString currentFile : FoundFiles)
	{
		FFAItems.AddUnique(MakeShared<FFAItem>(FFAItem(currentFile)));
	}
}

void SFavoritesPanel::RefreshList()
{
	RefreshFFAItems();
	if(ConstructedTileView.IsValid())
	{
		ConstructedTileView->RebuildList();
	}
}

FReply SFavoritesPanel::HandleAddNewFileButton()
{
	FFileAssistantModule& FileAssistantModule = FModuleManager::LoadModuleChecked<FFileAssistantModule>(FName(FAUtilities::GetFileAssistantName()));
	if(FileAssistantModule.ExecuteAddNewFile())
	{
		RefreshList();
		return FReply::Handled();
	}
	return FReply::Unhandled();
}

FReply SFavoritesPanel::HandleAddNewFolderButton()
{
	FFileAssistantModule& FileAssistantModule = FModuleManager::LoadModuleChecked<FFileAssistantModule>(FName(FAUtilities::GetFileAssistantName()));
	if(FileAssistantModule.ExecuteAddNewFolder())
	{
		RefreshList();
		return FReply::Handled();
	}
	return FReply::Unhandled();
}

void SFavoritesPanel::BindCommands()
{
	FileAssistantCommands = MakeShareable( new FUICommandList );
	
	FileAssistantCommands->MapAction(FGenericCommands::Get().Rename,FUIAction(
		FExecuteAction::CreateSP(this, &SFavoritesPanel::HandleRenameCommand),
		FCanExecuteAction::CreateSP(this, &SFavoritesPanel::HandleRenameCommandCanExecute)
	));
	
	FileAssistantCommands->MapAction(FGenericCommands::Get().Delete,FUIAction(
		FExecuteAction::CreateSP(this, &SFavoritesPanel::HandleDeleteCommand),
		FCanExecuteAction::CreateSP(this, &SFavoritesPanel::HandleDeleteCommandCanExecute)
	));

	FileAssistantCommands->MapAction(FGenericCommands::Get().SelectAll,FUIAction(
		FExecuteAction::CreateSP(this, &SFavoritesPanel::HandleSelectAllCommand),
		FCanExecuteAction::CreateSP(this, &SFavoritesPanel::HandleSelectAllCommandCanExecute)
	));
	
	//FInputBindingManager::Get().RegisterCommandList(FileAssistantCommands::Get().GetContextName(), Commands.ToSharedRef());
}

bool SFavoritesPanel::HandleRenameCommandCanExecute()
{
	if(ConstructedTileView.IsValid())
	{
		if (ConstructedTileView->GetNumItemsSelected() == 1)
		{
			return true;
		}
	}
	return false;
}

void SFavoritesPanel::HandleRenameCommand()
{
	TSharedPtr<FFAItem> SelectedItem = ConstructedTileView->GetSelectedItems()[0];
	/*2...user process OnRenameRequested, call &SInlineEditableTextBlock::EnterEditingMode*/
	SelectedItem->OnRenameRequested().ExecuteIfBound();
}

bool SFavoritesPanel::HandleDeleteCommandCanExecute()
{
	if(ConstructedTileView.IsValid())
	{
		if(ConstructedTileView->GetNumItemsSelected() > 0)
		{
			return true;
		}
	}
	return false;
}

void SFavoritesPanel::HandleDeleteCommand()
{
	FText Title = FText::FromString(TEXT("Warning"));
	FText Message = FText::FromString(TEXT("Are you sure you want to delete the favorited files/folders?"));
	if(FMessageDialog::Open(EAppMsgType::OkCancel,Message,Title) == EAppReturnType::Ok)
	{
		for (const TSharedPtr<FFAItem> CurrentItem : ConstructedTileView->GetSelectedItems())
		{
			FAUtilities::DeleteIconAndShortcut(*CurrentItem->GetShortcutPath());
		}
		RefreshList();
	}
}

bool SFavoritesPanel::HandleSelectAllCommandCanExecute()
{
	return ConstructedTileView.IsValid();
}

void SFavoritesPanel::HandleSelectAllCommand()
{
	/*why input one item can make all selected?*/
	ConstructedTileView->SetSelection(FFAItems[0],ESelectInfo::Direct);
}

void SFavoritesPanel::AssetRenameBegin(const TSharedPtr<FFAItem>& Item, const FString& LastName)
{
	/*6...execute this*/
	ItemName = LastName;
}

void SFavoritesPanel::AssetRenameCommit(const TSharedPtr<FFAItem>& Item, const FString& NewName,
	const ETextCommit::Type CommitType)
{
	if(FAUtilities::RenameIconAndShortcut(ItemName,NewName))
	{
		FIconStyle::RefreshSet();
		RefreshList();
	}
	ItemName.Empty();
}